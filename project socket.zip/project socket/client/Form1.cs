﻿using System;
using System.Globalization;
using System.IO;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace client
{
    // Finestra principale del client: mostra lo stato dell'asta
    // e permette all'utente di inviare offerte al server.
    public partial class Form1 : Form
    {
        private TcpClient _tcpClient;
        // Reader e writer usano la stessa connessione TCP:
        // il reader riceve aggiornamenti, il writer invia comandi.
        private StreamReader _reader;
        private StreamWriter _writer;

        public Form1()
        {
            InitializeComponent();
        }

        private async void btnConnect_Click(object sender, EventArgs e)
        {
            // Evita di aprire una seconda connessione dalla stessa finestra.
            if (_tcpClient != null && _tcpClient.Connected) return;
            try
            {
                _tcpClient = new TcpClient();
                // ConnectAsync evita di bloccare la grafica mentre si stabilisce
                // la connessione con il server.
                await _tcpClient.ConnectAsync(txtHost.Text.Trim(), 5000);
                _reader = new StreamReader(_tcpClient.GetStream(), Encoding.UTF8);
                _writer = new StreamWriter(_tcpClient.GetStream(), Encoding.UTF8) { AutoFlush = true };
                await _writer.WriteLineAsync("NAME|" + txtName.Text.Trim());
                // Le offerte restano disabilitate fino alla connessione.
                btnConnect.Enabled = false;
                btnBid.Enabled = true;
                lblStatus.Text = "Connesso";
                AddLog("Connesso al server.");
                _ = ReceiveLoopAsync();
            }
            catch (Exception ex)
            {
                lblStatus.Text = "Errore di connessione";
                AddLog(ex.Message);
                CloseConnection();
            }
        }

        private async void btnBid_Click(object sender, EventArgs e)
        {
            decimal amount;
            // Il client controlla il formato; la validità rispetto al prezzo
            // corrente viene verificata sempre dal server.
            if (_writer == null || !decimal.TryParse(txtBid.Text, NumberStyles.Number, CultureInfo.InvariantCulture, out amount))
            {
                AddLog("Inserisci un importo valido.");
                return;
            }

            try
            {
                // Il server stabilisce se l'importo è maggiore del prezzo corrente.
                await _writer.WriteLineAsync("BID|" + amount.ToString("0.00", CultureInfo.InvariantCulture));
            }
            catch (IOException)
            {
                AddLog("Connessione persa.");
                CloseConnection();
            }
        }

        private async Task ReceiveLoopAsync()
        {
            try
            {
                string line;
                // Il ciclo resta in ascolto degli aggiornamenti inviati dal server.
                while ((line = await _reader.ReadLineAsync()) != null)
                    ProcessMessage(line);
            }
            catch (IOException) { }
            finally
            {
                if (!IsDisposed)
                    BeginInvoke(new Action(() =>
                    {
                        // Se ReadLineAsync restituisce null, il server ha chiuso
                        // la connessione: riabilitiamo il pulsante di accesso.
                        lblStatus.Text = "Disconnesso";
                        btnConnect.Enabled = true;
                        btnBid.Enabled = false;
                    }));
            }
        }

        private void ProcessMessage(string message)
        {
            // Interpreta il primo campo per capire quale aggiornamento visualizzare.
            string[] parts = message.Split('|');
            if (parts.Length == 0) return;
            Action update = () =>
            {
                if (parts[0] == "STATE" && parts.Length >= 5)
                {
                    // STATE aggiorna i dati principali mostrati nella schermata.
                    lblItem.Text = "Oggetto: " + parts[1];
                    lblPrice.Text = "Prezzo: " + parts[2];
                    lblTime.Text = parts[3] == "-1" ? "Tempo: in corso" : "Tempo: " + parts[3] + " s";
                    lblLeader.Text = "Offerente: " + parts[4];
                }
                else if (parts[0] == "NEW" && parts.Length >= 4)
                    // NEW viene registrato nel log; lo stato dettagliato
                    // arriverà subito dopo tramite STATE.
                    AddLog("Nuova asta: " + parts[1] + " (base " + parts[2] + ")");
                else if (parts[0] == "BID" && parts.Length >= 3)
                    AddLog(parts[1] + " ha offerto " + parts[2]);
                else if (parts[0] == "RESULT" && parts.Length >= 4)
                    // RESULT chiude logicamente l'asta nella schermata.
                    AddLog("Asta conclusa: " + parts[1] + " aggiudicato a " + parts[3] + " per " + parts[2]);
                else if ((parts[0] == "INFO" || parts[0] == "ERROR") && parts.Length >= 2)
                    AddLog(parts[1]);
            };

            if (IsDisposed) return;
            // Il ciclo di rete non gira sul thread grafico: BeginInvoke esegue
            // l'aggiornamento dei controlli nel thread corretto.
            try { BeginInvoke(update); } catch (InvalidOperationException) { }
        }

        private void AddLog(string text)
        {
            // Aggiunge un timestamp per rendere leggibile la cronologia eventi.
            if (txtLog.TextLength > 0) txtLog.AppendText(Environment.NewLine);
            txtLog.AppendText(DateTime.Now.ToString("HH:mm:ss") + " " + text);
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Avvisa il server prima di chiudere la socket.
            try { if (_writer != null) _writer.WriteLine("QUIT"); } catch (Exception) { }
            CloseConnection();
        }

        private void CloseConnection()
        {
            // Riporta i controlli allo stato iniziale per consentire
            // una nuova connessione.
            try { if (_tcpClient != null) _tcpClient.Close(); } catch (Exception) { }
            _tcpClient = null;
            btnConnect.Enabled = true;
            btnBid.Enabled = false;
        }
    }
}
