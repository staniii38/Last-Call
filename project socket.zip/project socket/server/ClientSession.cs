﻿using System;
using System.IO;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace server
{
    // Rappresenta un singolo client collegato al server.
    // Contiene la socket e gli strumenti per leggere e scrivere messaggi.
    internal sealed class ClientSession
    {
        private readonly TcpClient _tcpClient;
        private readonly StreamWriter _writer;
        private readonly object _writeLock = new object();

        public ClientSession(TcpClient tcpClient)
        {
            _tcpClient = tcpClient;
            // La comunicazione usa righe di testo UTF-8.
            Reader = new StreamReader(tcpClient.GetStream(), Encoding.UTF8);
            _writer = new StreamWriter(tcpClient.GetStream(), Encoding.UTF8)
            {
                AutoFlush = true
            };
        }

        // Il server legge i comandi del client da questa proprietà.
        public StreamReader Reader { get; private set; }

        // Il nome viene assegnato dopo la ricezione del comando NAME.
        public string Name { get; set; }

        public Task SendAsync(string message)
        {
            return Task.Run(() =>
            {
                try
                {
                    // Più attività possono inviare messaggi allo stesso client:
                    // il lock evita che due righe vengano mescolate.
                    lock (_writeLock)
                        _writer.WriteLine(message);
                }
                catch (IOException) { Close(); } // Il client ha chiuso la connessione.
                catch (ObjectDisposedException) { Close(); }
            });
        }

        public void Close()
        {
            // Chiudere TcpClient chiude anche il relativo NetworkStream.
            try { _tcpClient.Close(); }
            catch (Exception) { }
        }
    }
}
