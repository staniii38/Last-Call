﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Threading.Tasks;

namespace server
{
    // Coordina il funzionamento dell'intero server:
    // connessioni, ciclo delle aste, offerte e notifiche ai client.
    internal sealed class AuctionServer
    {
        // Durata di ogni asta e catalogo degli oggetti disponibili.
        private const int AuctionDurationSeconds = 30;
        private static readonly string[] Catalog =
        {
            "Quadro antico", "Console retro", "Orologio da collezione",
            "Bicicletta da corsa", "Macchina fotografica", "Chitarra vintage"
        };

        // Porta TCP sulla quale il server accetta le connessioni.
        private readonly int _port;
        // Il lock protegge i dati condivisi tra il thread delle aste
        // e i thread che gestiscono i singoli client.
        private readonly object _sync = new object();
        // Elenco di tutti i client attualmente collegati.
        private readonly List<ClientSession> _clients = new List<ClientSession>();
        private readonly Random _random = new Random();
        // Permette di interrompere in modo controllato i cicli asincroni.
        private CancellationTokenSource _cancellation;
        private TcpListener _listener;

        // Dati dell'asta attualmente in corso.
        private string _currentItem;
        private decimal _currentPrice;
        private string _highestBidder;
        private bool _auctionOpen;

        public AuctionServer(int port)
        {
            _port = port;
        }

        public void Start()
        {
            _cancellation = new CancellationTokenSource();
            _listener = new TcpListener(IPAddress.Any, _port);
            _listener.Start();

            // I due cicli lavorano in parallelo:
            // uno accetta connessioni, l'altro gestisce le aste.
            Task.Run(AcceptClientsAsync);
            Task.Run(() => AuctionLoopAsync(_cancellation.Token));
        }

        public void Stop()
        {
            if (_cancellation == null) return;

            // Segnala ai task di terminare e sblocca AcceptTcpClientAsync
            // chiudendo il listener.
            _cancellation.Cancel();
            _listener.Stop();

            lock (_sync)
            {
                // Chiude tutte le socket ancora attive prima di terminare.
                foreach (ClientSession client in _clients.ToList())
                    client.Close();
                _clients.Clear();
            }
        }

        private async Task AcceptClientsAsync()
        {
            while (!_cancellation.IsCancellationRequested)
            {
                try
                {
                    // AcceptTcpClientAsync non blocca il thread principale:
                    // il server può continuare a gestire le aste.
                    ClientSession client = new ClientSession(await _listener.AcceptTcpClientAsync());
                    lock (_sync) _clients.Add(client);

                    // Ogni client viene gestito indipendentemente dagli altri.
                    _ = Task.Run(() => HandleClientAsync(client));
                }
                catch (ObjectDisposedException) { return; }
                catch (SocketException) { return; }
            }
        }

        private async Task HandleClientAsync(ClientSession client)
        {
            try
            {
                await client.SendAsync(Protocol.Info("Connesso. Invia NAME|tuo_nome per partecipare."));
                string line;

                // Legge una riga alla volta finché il client resta collegato.
                while ((line = await client.Reader.ReadLineAsync()) != null)
                {
                    HandleCommand(client, line);
                }
            }
            catch (IOException) { }
            catch (ObjectDisposedException) { }
            finally
            {
                RemoveClient(client);
            }
        }

        private void HandleCommand(ClientSession client, string line)
        {
            // Ogni comando ha il formato COMANDO|valore, ad esempio NAME|Mario.
            string[] parts = line.Split(new[] { '|' }, 2);
            string command = parts[0].Trim().ToUpperInvariant();

            if (command == "NAME" && parts.Length == 2)
            {
                client.Name = CleanName(parts[1]);
                client.SendAsync(Protocol.Info("Benvenuto " + client.Name + "!"));
                // Se l'asta è già iniziata, il nuovo client riceve subito lo stato.
                SendCurrentState(client);
            }
            else if (command == "BID" && parts.Length == 2)
            {
                decimal amount;
                if (decimal.TryParse(parts[1], NumberStyles.Number, CultureInfo.InvariantCulture, out amount))
                    PlaceBid(client, amount);
                else
                    client.SendAsync(Protocol.Error("Offerta non valida."));
            }
            // QUIT non richiede una risposta: l'uscita viene gestita
            // dal ciclo di lettura quando il client chiude la connessione.
            else if (command != "QUIT")
            {
                client.SendAsync(Protocol.Error("Comando sconosciuto."));
            }
        }

        private async Task AuctionLoopAsync(CancellationToken cancellationToken)
        {
            int index = 0;
            while (!cancellationToken.IsCancellationRequested)
            {
                // Breve pausa tra un'asta e la successiva.
                await Delay(1000, cancellationToken);
                StartAuction(Catalog[index++ % Catalog.Length]);

                // Invia il conto alla rovescia ogni secondo.
                for (int seconds = AuctionDurationSeconds; seconds >= 0 && _auctionOpen; seconds--)
                {
                    BroadcastState(seconds);
                    await Delay(1000, cancellationToken);
                }

                FinishAuction();
                await Delay(3000, cancellationToken);
            }
        }

        private void StartAuction(string item)
        {
            lock (_sync)
            {
                _currentItem = item;
                // Il prezzo iniziale è scelto casualmente tra 100 e 500.
                _currentPrice = _random.Next(10, 51) * 10;
                _highestBidder = null;
                _auctionOpen = true;
            }

            // L'annuncio viene inviato dopo aver aggiornato tutti i dati,
            // così i client ricevono uno stato coerente.
            Broadcast(Protocol.NewAuction(item, _currentPrice, AuctionDurationSeconds));
        }

        private void FinishAuction()
        {
            string item;
            decimal price;
            string winner;
            lock (_sync)
            {
                _auctionOpen = false;
                item = _currentItem;
                price = _currentPrice;
                winner = string.IsNullOrEmpty(_highestBidder) ? "Nessun offerente" : _highestBidder;
            }

            // Il risultato viene inviato anche quando nessuno ha fatto offerte.
            Broadcast(Protocol.Result(item, price, winner));
        }

        private void PlaceBid(ClientSession client, decimal amount)
        {
            bool accepted;
            lock (_sync)
            {
                // La verifica deve essere atomica: due offerte simultanee
                // non devono poter aggiornare il prezzo in modo incoerente.
                accepted = _auctionOpen && amount > _currentPrice && !string.IsNullOrEmpty(client.Name);
                if (accepted)
                {
                    _currentPrice = amount;
                    _highestBidder = client.Name;
                }
            }

            if (accepted)
                // Una singola offerta valida viene notificata a tutti,
                // compreso il client che l'ha inviata.
                Broadcast(Protocol.Bid(client.Name, amount));
            else
                client.SendAsync(Protocol.Error("L'offerta deve essere maggiore del prezzo corrente e devi aver scelto un nome."));
        }

        private void BroadcastState(int seconds)
        {
            string item;
            decimal price;
            string bidder;
            lock (_sync)
            {
                item = _currentItem;
                price = _currentPrice;
                bidder = string.IsNullOrEmpty(_highestBidder) ? "-" : _highestBidder;
            }
            // Tutti i client devono vedere lo stesso stato dell'asta.
            Broadcast(Protocol.State(item, price, seconds, bidder));
        }

        private void SendCurrentState(ClientSession client)
        {
            lock (_sync)
            {
                if (_auctionOpen)
                    // -1 non è un tempo reale: significa "stato iniziale".
                    client.SendAsync(Protocol.State(_currentItem, _currentPrice, -1,
                        string.IsNullOrEmpty(_highestBidder) ? "-" : _highestBidder));
            }
        }

        private void Broadcast(string message)
        {
            ClientSession[] clients;
            lock (_sync) clients = _clients.ToArray();

            // Copia la lista prima di inviare per non mantenerne il lock
            // durante le operazioni di rete.
            foreach (ClientSession client in clients)
                client.SendAsync(message);
        }

        private void RemoveClient(ClientSession client)
        {
            lock (_sync) _clients.Remove(client);
            client.Close();
        }

        private static string CleanName(string name)
        {
            string cleaned = name.Replace("|", "").Trim();
            if (string.IsNullOrEmpty(cleaned)) return "Giocatore";
            // Limita la lunghezza del nome per evitare messaggi troppo grandi.
            return cleaned.Substring(0, Math.Min(20, cleaned.Length));
        }

        private static async Task Delay(int milliseconds, CancellationToken token)
        {
            // La cancellazione interrompe le attese quando il server viene chiuso.
            try { await Task.Delay(milliseconds, token); }
            catch (TaskCanceledException) { }
        }
    }
}
