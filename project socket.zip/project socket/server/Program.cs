﻿using System;

namespace server
{
    // Punto di ingresso del server: crea il gestore dell'asta e lo mantiene
    // attivo fino a quando l'utente preme INVIO nella console.
    internal static class Program
    {
        private static void Main(string[] args)
        {
            // Il server ascolta su tutte le interfacce di rete locali, porta 5000.
            AuctionServer auctionServer = new AuctionServer(5000);
            auctionServer.Start();

            Console.WriteLine("Final Call server in ascolto sulla porta 5000.");
            Console.WriteLine("Premere INVIO per arrestare il server.");
            Console.ReadLine();

            // Arresto ordinato: interrompe il listener e chiude i client collegati.
            auctionServer.Stop();
        }
    }
}
