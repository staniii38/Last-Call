﻿using System.Globalization;

namespace server
{
    // Costruisce i messaggi scambiati tra server e client.
    // Il protocollo è testuale: i campi sono separati dal carattere '|'.
    internal static class Protocol
    {
        public static string Info(string message)
        {
            // Messaggio informativo, visualizzato nel log del client.
            return "INFO|" + Clean(message);
        }

        public static string Error(string message)
        {
            // Errore di comando o di validazione dell'offerta.
            return "ERROR|" + Clean(message);
        }

        public static string NewAuction(string item, decimal price, int duration)
        {
            // Annuncia l'inizio di una nuova asta.
            return "NEW|" + Clean(item) + "|" + FormatPrice(price) + "|" + duration;
        }

        public static string State(string item, decimal price, int seconds, string bidder)
        {
            // seconds = -1 indica al client che sta ricevendo lo stato iniziale
            // dopo una connessione, non un aggiornamento del timer.
            return "STATE|" + Clean(item) + "|" + FormatPrice(price) + "|" + seconds + "|" + Clean(bidder);
        }

        public static string Bid(string bidder, decimal price)
        {
            // Notifica che il prezzo è stato aggiornato da una nuova offerta.
            return "BID|" + Clean(bidder) + "|" + FormatPrice(price);
        }

        public static string Result(string item, decimal price, string winner)
        {
            // Comunica l'aggiudicazione dell'oggetto.
            return "RESULT|" + Clean(item) + "|" + FormatPrice(price) + "|" + Clean(winner);
        }

        public static string FormatPrice(decimal price)
        {
            // InvariantCulture mantiene il punto come separatore decimale
            // indipendentemente dalla lingua del computer.
            return price.ToString("0.00", CultureInfo.InvariantCulture);
        }

        private static string Clean(string value)
        {
            // Il carattere '|' separa i campi: non deve comparire nei valori.
            return (value ?? "").Replace("|", " ");
        }
    }
}
